# Basic-Banking-App

### This Repo showcases my project, that I've created for my Internship task at The Sparks Foundation.

![PicsArt_04-06-12 44 05](https://user-images.githubusercontent.com/68140538/113625942-2e7eb180-967f-11eb-90dd-ae86c112ecfa.jpg)
![PicsArt_04-06-12 47 29](https://user-images.githubusercontent.com/68140538/113625947-30487500-967f-11eb-8e29-3bbd6f0dc8aa.jpg)
![PicsArt_04-06-02 19 41](https://user-images.githubusercontent.com/68140538/113625951-30e10b80-967f-11eb-82ca-4d9b26273c89.jpg)
![PicsArt_04-06-02 21 35](https://user-images.githubusercontent.com/68140538/113625953-3179a200-967f-11eb-8183-03a7bba3999d.jpg)
